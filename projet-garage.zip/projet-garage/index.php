<?php 

header('location: public/');