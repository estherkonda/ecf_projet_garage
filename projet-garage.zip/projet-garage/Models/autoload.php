<?php
include "Admin.php";
include "Employe.php";
include realpath("Utilisateur.php");
include "Visiteur.php";