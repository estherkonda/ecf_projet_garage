<?php
interface Temoignage{
    public function createTemoignage($data);
    public function selectAllTemoignage();
}
