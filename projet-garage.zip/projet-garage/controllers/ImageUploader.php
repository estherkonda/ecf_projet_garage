<?php

class ImageUploader {
    static public function uploadImage($file,$targetDir) {

        if(isset($_FILES["file"]) && $_FILES["file"]["error"] == 0){

        }
    }


}
