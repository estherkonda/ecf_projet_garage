<?php
header('location:app/views/pages/login.php');